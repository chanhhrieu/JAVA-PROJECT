/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J1LP_FruitShop;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class CheckValid {

    Scanner sc = new Scanner(System.in);

    public int checkLimit(int max, int min) {
        while (true) {
            try {
                int input = Integer.parseInt(sc.next());
                if (input < min || input > max) {
                    throw new Exception();
                }
                return input;
            } catch (Exception e1) {
                System.err.println("You must enter number between: [" + min + ", " + max + "]");
                System.out.print("Enter again: ");
            }
        }
    }

    public String checkInputString() {
        while (true) {
            String input = sc.next();
            if (input.isEmpty()) {
                System.out.println("String must not empty: ");
            }
            return input;
        }
    }

    public double checkInputDouble() {
        while (true) {
            try {
                double input = Double.parseDouble(sc.next());
                if (input < 0) {
                    throw new NumberFormatException();
                }
                return input;
            } catch (NumberFormatException e) {
                System.err.println("Please enter number!!!");
                System.out.print("Enter again: ");
            }

        }
    }

    public int checkInputInt() {
        while (true) {
            try {
                int input = Integer.parseInt(sc.next());
                if (input < 0) {
                    throw new NumberFormatException();
                }
                return input;

            } catch (NumberFormatException e) {
                System.err.println("Please enter number!!!");
                System.out.print("Enter again: ");
            }
        }
    }

    public boolean checkInputYN() {
        while (true) {
            String input = sc.next();
            if (input.equalsIgnoreCase("Y")) {
                return true;
            }
            if (input.equalsIgnoreCase("N")) {
                return false;
            }
        }
    }

}
