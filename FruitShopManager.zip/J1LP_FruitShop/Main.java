/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J1LP_FruitShop;

/**
 *
 * @author admin
 */
public class Main {

    public static void main(String[] args) {
        while (true) {
            CheckValid cv = new CheckValid();
            ManageFruit mf = new ManageFruit();
            System.out.println("Fruit Shop System ");
            System.out.println("1. Create Fruit ");
            System.out.println("2. View orders ");
            System.out.println("3. Shopping(for buyer)");
            System.out.println("4. Exit");
            System.out.println("Enter your choice: ");
            int choice = cv.checkLimit(4, 1);
            switch (choice) {
                case 1:
                    mf.createFruit();
                    break;
                case 2:
                    mf.viewOrders();
                    break;
                case 3:
                    mf.shoppingFruit();
                    break;
                case 4:
                    return;
            }
        }
    }

}
