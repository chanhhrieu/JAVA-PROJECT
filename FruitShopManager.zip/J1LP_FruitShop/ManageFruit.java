/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package J1LP_FruitShop;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class ManageFruit {

    ArrayList<Fruit> fl = new ArrayList<>();
    CheckValid cv = new CheckValid();
    ArrayList<Order> lo = new ArrayList<>();

    public void createFruit() {
        while (true) {
            System.out.println("Enter fruit ID: ");
            String id = cv.checkInputString();
            System.out.println("Enter fruit name: ");
            String name = cv.checkInputString();
            System.out.println("Enter fruit price: ");
            double price = cv.checkInputDouble();
            System.out.println("Enter fruit quantity: ");
            int quantity = cv.checkInputInt();
            System.out.println("enter fruit origin: ");
            String origin = cv.checkInputString();
            fl.add(new Fruit(id, name, price, quantity, origin));
            System.out.println("Do you want to continue ?");
            if (!cv.checkInputYN()) {
                break;
            }
        }
    }

    public Fruit getFruitByID(String id) {
        for (Fruit i : fl) {
            if (id.equalsIgnoreCase(i.getFruitID())) {
                return i;
            }
        }
        return null;
    }

    public Fruit getFruitByIteam(int item) {
        int countItem = 1;
        for (Fruit i : fl) {
            if (i.getFruitQuantity() != 0) {
                countItem++;
            }
            if (countItem - 1 == item) {
                return i;
            }

        }
        return null;
    }

    public void displayListFruit() {
        int countItem = 1;
        for (Fruit i : fl) {
            if (i.getFruitQuantity() != 0) {
                System.out.printf("%-10d%-20s%-20s%-15.0f$\n", countItem++, i.getFruitName(), i.getFruitOrigin(), i.getFruitPrice());
            }
        }
    }

    public void viewOrders() {
        for (Order i : lo) {
            System.out.println("Product: " + i.getFruitName() + "Quantity:");
        }

    }

    public void shoppingFruit() {
        while (true) {
            displayListFruit();
            System.out.println("Enter item: ");
            int item = cv.checkLimit(fl.size(), 1);
            Fruit fruit = getFruitByIteam(item);
            System.out.println("Enter quantity: ");
            int quantity = cv.checkLimit(fl.size(), 1);
            fruit.setFruitQuantity(fruit.getFruitQuantity() - quantity);
            lo.add(new Order(fruit.fruitID, fruit.fruitName, quantity, fruit.getFruitPrice()));
            System.out.println(" do you want to buy now ?");
            if (!cv.checkInputYN()) {
                break;
            }
        }
        for (Order i : lo) {
            System.out.println(i.getFruitId() + ", " + i.getFruitName() + ", " + i.getPrice() + ", " + i.getQuantity());
        }

    }
}
