/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package HE181228_chanhndb_IA1803.s.P0001;

//import java.util.Arrays;
//import java.util.Scanner;

public class BubbleSort {
    
    public static void main(String[] args) {
        // 1. Display number & Input
        int n = Display.displayInput();
        // 2. Generate random integer in array
        int[] arr = Display.randomArray(n);
        // 3. Display array before sorting
        Display.displayArrayBeforeSort(n, arr);
        // 4. Display array after sorting
        Display.bubbleSort (5,arr,8);
//        Display.displayArrayBeforeSort(arr);
    }
    
}
