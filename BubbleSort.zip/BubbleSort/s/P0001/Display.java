/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HE181228_chanhndb_IA1803.s.P0001;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Display {

    public static int displayInput() {
        // 1. Display number & Input 
        int numberInput = 0;// dùng để display decamical
        Scanner sc = new Scanner(System.in);
        // dùng try catch bắt các lỗi số âm, string, ký tự khác
        do {
            try {
                System.out.print("Enter number of array: "); // Display ask users
                numberInput = Integer.parseInt(sc.nextLine());// chuyển đổi người nhập sang hệ số binary
                if (numberInput < 0) {
                    throw new Exception("Not negative number input. Please try again");
                }
            } catch (NumberFormatException e) {
                System.out.println(e);
            } catch (Exception e) {
                System.out.println(e);
            }

        } while (numberInput < 0);
        return numberInput;
    }

    public static int[] randomArray(int numberInput) {

        //2. Generate random integer in arrray in number size 
        int array[] = new int[numberInput];
        Random randArray = new Random(); //tao random object
        for (int i = 0; i < numberInput; i++) {
            array[i] = randArray.nextInt(10);
        }
        return array;
    }

    public static void displayArrayBeforeSort(int numberInput, int array[]) {
        //3. Display array before sorting
        System.out.print("Unsorted Array: [");
        for (int i = 0; i < numberInput; i++) {
            System.out.print(array[i]);
            if (i < numberInput - 1) // nếu số đó không phải số cuối cùng thêm vào ','
            {
                System.out.print(", ");
            }
        }
        System.out.println("]");

    }

    public static void bubbleSort(int beginIndex, int array[], int lastIndex) {
        System.out.print("Sorted Array: [");
        int temp;
        for (int i = 0; i < array.length; i++) {
            for (int j = beginIndex; j < lastIndex; j++) {
                if (array[j] > array[j + 1]) {
                    temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                }
            }
            System.out.print(array[i]+", ");
        }

        System.out.print("]");
    }

}
