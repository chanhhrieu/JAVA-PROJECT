/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HE181228_chanhndb_IA1803_J1SH23;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class checkvalid {

    Scanner sc = new Scanner(System.in);

    public int checkLimit(int min, int max) {
        while (true) {
            try {
                int choice = Integer.parseInt(sc.next());
                if (choice < min || choice > max) {
                    throw new NumberFormatException();
                }
                return choice;

            } catch (NumberFormatException e) {
                System.err.println("Not valid. Please import from :[" + min + ", " + max + "]");
                System.out.print("Enter:");
            }
        }
    }
    public  String checkInputString() {
        while (true) {
            Scanner sc = new Scanner(System.in);
            String input = sc.next();
            if (input.isEmpty()) {
                System.out.println("String must not empty: ");
            }
            return input;
        }
    }

}
