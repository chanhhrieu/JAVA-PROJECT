/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HE181228_chanhndb_IA1803_J1SH23;

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        checkvalid cv = new checkvalid();
        // Create a new clerk
        GroceryBill.Employee clerk = new GroceryBill.Employee();
        clerk.setName("Clerk");

        // Create a new GroceryBill
        GroceryBill bill = new GroceryBill(clerk);

        // Create a DiscountBill
        DiscountBill discountBill = new DiscountBill(true, 1, 5.0, 10.0, clerk);
        while (true) {
            System.out.println("1. Add item");
            System.out.println("2. total");
            System.out.println("3. total after discount");
            System.out.println("4. Exit ");
            int choice = cv.checkLimit(1, 3);
            switch (choice) {
                case 1:

                    GroceryBill.Item item = new GroceryBill.Item();
                    for (int i = 0; i < 10; i++) {
                        item.setPrice(10.0 + i); // Set price
                        item.setDiscount(i * 0.5); // Set discount
                        bill.add(item);
                        discountBill.add(item);
                    }
                    break;
                case 2:
                    System.out.println("Total: " + bill.getTotal());
                    break;
                case 3:
                    System.out.println("Total after discount: " + discountBill.getTotal());
                    break;
                case 4:
                    return;
            }
        }
    }
}
