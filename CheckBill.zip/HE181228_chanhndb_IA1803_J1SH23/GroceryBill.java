/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HE181228_chanhndb_IA1803_J1SH23;

import java.util.ArrayList;
import java.util.List;
//import javax.swing.border.EmptyBorder;

/**
 *
 * @author admin
 */
public class GroceryBill {
    
    private Employee clerk;
    private final ArrayList<Item> rp;
    private double total;
    private double discount;
    
    public Employee getClerk() {
        return clerk;
        
    }
    
    public double getDiscount() {
        return discount;
    }
    
    public void setDiscount(double discount) {
        this.discount = discount;
    }
    
    public void setClerk(Employee clerk) {
        this.clerk = clerk;
        this.total = 0.0;
        this.discount = 0.0;
    }
//1  

    public GroceryBill(Employee clerk) {
        this.clerk = clerk;
        rp = new ArrayList<Item>();
    }

//2 add i to thiss bill's
    public void add(Item i) {
        rp.add(i);
        total += i.getPrice();
        discount += i.getDiscount();
    }
//3

    public double getTotal() {
        return total;
    }
//4

    public void printReceipt() {
        for(int i = 0; i< rp.size(); i++)
        {
            System.out.println(rp.get(i));
        }
        
    }
    
    public static class Employee {
        
        private String name;
        
        public String getName() {
            return name;
        }
        
        public void setName(String name) {
            this.name = name;
        }
        
    }
    
    public static class Item {
        
        private double price;
        private double discount;
        
        public double getPrice() {
            return price;
        }
        
        public void setPrice(double price) {
            this.price = price;
        }
        
        public double getDiscount() {
            return discount;
        }
        
        public void setDiscount(double discount) {
            this.discount = discount;
        }
    }
    
}
