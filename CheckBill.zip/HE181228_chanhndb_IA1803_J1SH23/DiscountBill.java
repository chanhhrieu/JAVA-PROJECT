/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HE181228_chanhndb_IA1803_J1SH23;

/**
 *
 * @author admin
 */
public class DiscountBill extends GroceryBill {

    private boolean preferred;
    private int DiscountCount;
    private double DiscountAmount;
    private double DiscountPercent;

    public boolean isPreferred() {
        return preferred;
    }

    public void setPreferred(boolean preferred) {
        this.preferred = preferred;
    }
//1

    public int getDiscountCount() {
        return DiscountCount;
    }

    public void setDiscountCount(int DiscountCount) {
        this.DiscountCount = DiscountCount;
    }
//3

    public double getDiscountAmount() {
        return DiscountAmount;
    }

    public void setDiscountAmount(double DiscountAmount) {
        this.DiscountAmount = DiscountAmount;
    }
//4
// vd 0.25 disscount va 1.35 tong -> 0.25: 1.35 x 100 

    public double getDiscountPercent() {
        return DiscountAmount / super.getTotal() * 100;
    }

    public void setDiscountPercent(double DiscountPercent) {
        this.DiscountPercent = DiscountPercent;
    }

    public DiscountBill(boolean preferred, int DiscountCount, double DiscountAmount, double DiscountPercent, Employee clerk) {
        super(clerk);
        this.preferred = preferred;
        this.DiscountCount = DiscountCount;
        this.DiscountAmount = DiscountAmount;
        this.DiscountPercent = DiscountPercent;
    }

    @Override
    public double getTotal() {
        return super.getTotal() - DiscountAmount;

    }
//  You should also keep track of how many items a customer is 
//getting a non-zero discount for and the overall discount, both as a total amount and as a percentage of 
//the original bill. 

    @Override
    public void add(Item i) {
        super.add(i);
        if (preferred == true && i.getDiscount() > 0) {
            DiscountCount++;
            DiscountAmount += i.getDiscount();
        }

    }
}
