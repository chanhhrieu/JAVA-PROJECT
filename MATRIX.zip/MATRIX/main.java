/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MATRIX;

/**
 *
 * @author admin
 */
public class main {

    public static void main(String[] args) {
        view v = new view();
        checkValid cv = new checkValid();

        while (true) {
            System.out.println("Calculator program: ");
            System.out.println("1. Addition matrix");
            System.out.println("2. Subtraction matrix");
            System.out.println("3. Muliplication matrix");
            System.out.println("4. Quit");
            System.out.println("Your choice");
            int choice = cv.checkInputLimit(1, 4);
            switch (choice) {
                case 1:
                    v.addmx();
                    break;

                case 2:
                    v.submx();
                    break;
                case 3:
                    v.multi();
                    break;
                case 4:
                    return;
            }

        }
    }
}
