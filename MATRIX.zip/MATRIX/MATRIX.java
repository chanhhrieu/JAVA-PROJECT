package MATRIX;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author admin
 */
public class MATRIX {

    int[][] matrix;

    public MATRIX() {
    }

    public int[][] getMatrix() {
        return matrix;
    }

    public void setMatrix(int[][] matrix) {
        this.matrix = matrix;
    }

    public checkValid getCv() {
        return cv;
    }

    public void setCv(checkValid cv) {
        this.cv = cv;
    }

    public MATRIX(int r, int c) {
        this.matrix = new int[r][c];
    }

    checkValid cv = new checkValid();

    public int[][] adds() {

        for (int r = 0; r < matrix.length; r++) {
            for (int c = 0; c < matrix[0].length; c++) {
                System.out.println("Enter matrix" + ": " + "[" + (r + 1) + "]" + "[" + (c + 1) + "] : ");
                matrix[r][c] = cv.checkInpuINT();
            }
        }
        return matrix;
    }

    public void displayMatrix() {
        int row1 = matrix.length;
        int col1 = matrix[0].length;
        for (int r2 = 0; r2 < row1; r2++) {
            for (int c2 = 0; c2 < col1; c2++) {
                System.out.print("[" + matrix[r2][c2] + "]");
            }
            System.out.println();
        }

    }

    public MATRIX additionMatrix(MATRIX a) {

        int row1 = matrix.length;
        int col1 = matrix[0].length;
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print("[" + (matrix[i][j] + a.matrix[i][j]) + "]");
            }
            System.out.println();
        }
        return null;
    }

    public MATRIX subtractionMatrix(MATRIX a) {
        int row1 = matrix.length;
        int col1 = matrix[0].length;
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                System.out.print("[" + (matrix[i][j] - a.matrix[i][j]) + "]");
            }
            System.out.println();
        }
        return null;
    }

    public MATRIX multiplicationMatrix(MATRIX a) {
        int row1 = matrix.length;
        int col1 = matrix[0].length;
        MATRIX resultMatrix = new MATRIX(row1, a.getMatrix()[0].length);

        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < a.matrix[0].length; j++) {
                for (int k = 0; k < col1; k++) {
                    resultMatrix.matrix[i][j] += matrix[i][k] * a.matrix[k][j];
                }
            }
        }
        return resultMatrix;
    }
}
