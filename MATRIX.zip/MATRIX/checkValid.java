/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MATRIX;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class checkValid {

    Scanner sc = new Scanner(System.in);

    public int checkInputLimit(int min, int max) {
        while (true) {
            try {
                int input = Integer.parseInt(sc.next());
                if (input < min || input > max) {
                    throw new Exception();
                }
                return input;
            } catch (Exception e) {
                System.out.print("Please input an integer number from  ");
            }
        }
    }

    public int checkInpuINT() {
        while (true) {
            try {
                int input = Integer.parseInt(sc.nextLine());
               
                return input;
            } catch (NumberFormatException e) {
                System.out.println("Please enter again: ");
            }
        }
    }

}
