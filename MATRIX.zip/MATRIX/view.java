/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MATRIX;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class view {

    checkValid cv = new checkValid();

    Matrixmanagement m = new Matrixmanagement();

    public MATRIX genMAtrix(int n) {
        System.out.println("Enter row Matrix " + n + ": ");
        int row = cv.checkInpuINT();
        System.out.println("ENter collum matrix " + n + ": ");
        int col = cv.checkInpuINT();
        MATRIX c1 = new MATRIX(row, col);
        c1.adds();
        return c1;

    }

    public ArrayList<MATRIX> addmx() {
        ArrayList<MATRIX> lm = new ArrayList<>();
        System.out.println("Add Matrix: ");
        MATRIX c1 = genMAtrix(1);
        MATRIX c2 = genMAtrix(2);
        lm.add(c2);
        lm.add(c1);
        m.addm(lm);
        return lm;
    }

    public ArrayList<MATRIX> submx() {
        ArrayList<MATRIX> lm = new ArrayList<>();
        System.out.println("sub matrix: ");
        MATRIX c1 = genMAtrix(1);
        MATRIX c2 = genMAtrix(2);
        lm.add(c2);
        lm.add(c1);
        m.subm(lm);
        return lm;
    }

    public ArrayList<MATRIX> multi() {
        ArrayList<MATRIX> lm = new ArrayList<>();
        System.out.println("sub matrix: ");
        MATRIX c1 = genMAtrix(1);
        MATRIX c2 = genMAtrix(2);
        lm.add(c2);
        lm.add(c1);
        m.multi(lm);
        return lm;
    }

}
