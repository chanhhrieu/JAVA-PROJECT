/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MATRIX;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Matrixmanagement {

    public void addm(ArrayList<MATRIX> lm) {
        if (lm.get(0).getMatrix().length == lm.get(1).getMatrix().length && lm.get(0).getMatrix()[0].length == lm.get(1).getMatrix()[0].length) {
            System.out.println("Result");
            lm.get(0).displayMatrix();
            System.out.println("+");
            lm.get(1).displayMatrix();
            System.out.println("=");
            lm.get(0).additionMatrix(lm.get(1));
        } else {
            System.out.println("Can not add ");
        }
    }

    public void subm(ArrayList<MATRIX> lm) {
        if (lm.get(0).getMatrix().length == lm.get(1).getMatrix().length && lm.get(0).getMatrix()[0].length == lm.get(1).getMatrix()[0].length) {
            System.out.println("Result");
            lm.get(0).displayMatrix();
            System.out.println("-");
            lm.get(1).displayMatrix();
            System.out.println("=");
            lm.get(0).subtractionMatrix(lm.get(1));
        } else {
            System.out.println("Can not sub ");
        }
    }

    public void multi(ArrayList<MATRIX> lm) {
        if (lm.get(0).getMatrix().length == lm.get(1).getMatrix()[0].length && lm.get(0).getMatrix()[0].length == lm.get(1).getMatrix().length) {
            System.out.println("Result");
            lm.get(0).displayMatrix();
            System.out.println("+");
            lm.get(1).displayMatrix();
            System.out.println("=");
            lm.get(0).multiplicationMatrix(lm.get(1)).displayMatrix();
        } else {
            System.out.println("Can not multi");
        }

    }

}
